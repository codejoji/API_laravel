<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Location;
use Illuminate\Support\Facades\Storage;
USE App\Models\PlantDetail;

class LocationController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }
   
    
    /**
     * Store a newly created resource in storage.
     */
    public function create(Request $request)
    {
        // $validated = $request->validate([
        //     'title' => ['required'],
        // ]);
        
        $pimage = $request->file('img')->store('img','public');

        $location = new Location;
        $location->title = $request->title;
        $location->desc = $request->desc;
        $location->cost = $request->cost;
        $location->img = $pimage;
        $location->save();
        return response([
            "result" => $location,
        ],200);
        
    }

    /**
     * Display the specified resource.
     */

    public function showwithplantdetail(){
        $details=Location::with(['PlantDetail'])->get();
        if(isset($details)){
                return response([
                    "result" => $details,
                ],200);

        }
        else{
            return response([
                "result"=>"no response",
            ],200);
        }
    }
    public function show()
    {
        $data=Location::all();
        foreach($data as $data2){
            $url=Storage::url($data2->img);
            $data2->imgpath='https://ngo.rasayanudyog.co.in'.''.$url;
        }

        // $data = DB::select('select * from students');
 
        // return response([
        //     "message" => $data,
        // ],200);
        return response([
            "result" => $data
        ],200);
    }
    public function showbyid(string $id)
    {
        $data=Location::where('id', $id)->get();
        foreach($data as $data2){
            $url=Storage::url($data2->img);
            $data2->imgpath='http://127.0.0.1:8000'.''.$url;
        }
        return response([
            "result" => $data,
        ],200);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
